import React, { useState, useEffect, createContext, useContext, useReducer, useCallback, useMemo, useRef, useLayoutEffect, useDebugValue } from 'react';
import { createRoot } from 'react-dom/client';
import * as THREE from 'three';
import { Line, Bar } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend } from 'chart.js';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import gsap from 'gsap';

// Register ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend);

// ==================== FORM VALIDATION SCHEMA ====================
const contactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  message: z.string().min(10, 'Message must be at least 10 characters')
});

// ==================== 3D BACKGROUND COMPONENT ====================
function ThreeDBackground() {
  const mountRef = useRef(null);

  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0a0a2a);

    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    camera.position.z = 30;

    const renderer = new THREE.WebGLRenderer({ alpha: false });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(window.devicePixelRatio);
    mountRef.current.appendChild(renderer.domElement);

    const particlesGeometry = new THREE.BufferGeometry();
    const particlesCount = 2000;
    const posArray = new Float32Array(particlesCount * 3);
    
    for (let i = 0; i < particlesCount; i++) {
      posArray[i * 3] = (Math.random() - 0.5) * 100;
      posArray[i * 3 + 1] = (Math.random() - 0.5) * 60;
      posArray[i * 3 + 2] = (Math.random() - 0.5) * 50;
    }
    
    particlesGeometry.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    
    const particlesMaterial = new THREE.PointsMaterial({
      size: 0.2,
      color: 0x00aaff,
      transparent: true,
      opacity: 0.6,
      blending: THREE.AdditiveBlending
    });
    
    const particlesMesh = new THREE.Points(particlesGeometry, particlesMaterial);
    scene.add(particlesMesh);

    const cubes = [];
    for (let i = 0; i < 50; i++) {
      const geometry = new THREE.BoxGeometry(0.3, 0.3, 0.3);
      const material = new THREE.MeshStandardMaterial({ color: 0x00ffaa, emissive: 0x004400 });
      const cube = new THREE.Mesh(geometry, material);
      cube.position.x = (Math.random() - 0.5) * 80;
      cube.position.y = (Math.random() - 0.5) * 50;
      cube.position.z = (Math.random() - 0.5) * 40;
      scene.add(cube);
      cubes.push(cube);
    }

    const ambientLight = new THREE.AmbientLight(0x404040);
    scene.add(ambientLight);
    
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);
    
    const pointLight = new THREE.PointLight(0x00aaff, 0.5);
    pointLight.position.set(0, 0, 10);
    scene.add(pointLight);

    let time = 0;
    const animate = () => {
      requestAnimationFrame(animate);
      time += 0.005;
      
      particlesMesh.rotation.y = time * 0.1;
      particlesMesh.rotation.x = Math.sin(time * 0.2) * 0.1;
      
      cubes.forEach((cube, i) => {
        cube.rotation.x += 0.01;
        cube.rotation.y += 0.02;
        cube.rotation.z += 0.015;
        cube.position.y += Math.sin(time + i) * 0.005;
      });
      
      camera.position.x = Math.sin(time * 0.1) * 2;
      camera.position.y = Math.cos(time * 0.15) * 1.5;
      camera.lookAt(0, 0, 0);
      
      renderer.render(scene, camera);
    };
    
    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
      if (mountRef.current && renderer.domElement) {
        mountRef.current.removeChild(renderer.domElement);
      }
    };
  }, []);

  return <div ref={mountRef} style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: -1 }} />;
}

// ==================== CUSTOM HOOKS ====================
function useLocalStorage(key, initialValue) {
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.log(error);
      return initialValue;
    }
  });
  useDebugValue(storedValue);
  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.log(error);
    }
  };
  return [storedValue, setValue];
}

function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(handler);
  }, [value, delay]);
  return debouncedValue;
}

function useWindowSize() {
  const [size, setSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  useEffect(() => {
    const handler = () => setSize({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener('resize', handler);
    return () => window.removeEventListener('resize', handler);
  }, []);
  return size;
}

function useOnlineStatus() {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  return isOnline;
}

// ==================== CONTEXTS ====================
const ThemeContext = createContext();
const UserContext = createContext();
const NotificationContext = createContext();
const ModalContext = createContext();

// ==================== REDUCERS ====================
const initialState = { 
  count: 0, 
  step: 1, 
  user: null, 
  loading: false, 
  error: null,
  notifications: [],
  modals: []
};

function reducer(state, action) {
  switch (action.type) {
    case 'INCREMENT': return { ...state, count: state.count + state.step };
    case 'DECREMENT': return { ...state, count: state.count - state.step };
    case 'SET_STEP': return { ...state, step: action.payload };
    case 'SET_USER': return { ...state, user: action.payload, loading: false };
    case 'SET_LOADING': return { ...state, loading: action.payload };
    case 'SET_ERROR': return { ...state, error: action.payload, loading: false };
    case 'ADD_NOTIFICATION': return { ...state, notifications: [...state.notifications, action.payload] };
    case 'REMOVE_NOTIFICATION': return { ...state, notifications: state.notifications.filter(n => n.id !== action.payload) };
    case 'SHOW_MODAL': return { ...state, modals: [...state.modals, action.payload] };
    case 'HIDE_MODAL': return { ...state, modals: state.modals.filter(m => m.id !== action.payload) };
    default: return state;
  }
}

// ==================== ANIMATION COMPONENT ====================
function FadeIn({ children, delay = 0 }) {
  const [isVisible, setIsVisible] = useState(false);
  useLayoutEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), delay);
    return () => clearTimeout(timer);
  }, [delay]);
  return (
    <div style={{
      opacity: isVisible ? 1 : 0,
      transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
      transition: 'opacity 0.5s ease, transform 0.5s ease'
    }}>
      {children}
    </div>
  );
}

// ==================== COMPONENTS ====================
function Notifications() {
  const { state, dispatch } = useContext(NotificationContext);
  useEffect(() => {
    if (state.notifications.length > 0) {
      const timer = setTimeout(() => {
        dispatch({ type: 'REMOVE_NOTIFICATION', payload: state.notifications[0].id });
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [state.notifications, dispatch]);
  return (
    <div style={{ position: 'fixed', top: 20, right: 20, zIndex: 1000 }}>
      {state.notifications.map(notif => (
        <div key={notif.id} style={{
          background: notif.type === 'error' ? '#dc3545' : notif.type === 'success' ? '#28a745' : '#007bff',
          color: 'white',
          padding: '12px 20px',
          marginBottom: 10,
          borderRadius: 5,
          boxShadow: '0 2px 10px rgba(0,0,0,0.2)',
          animation: 'slideIn 0.3s ease'
        }}>
          {notif.message}
        </div>
      ))}
      <style>{`
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `}</style>
    </div>
  );
}

function Modal() {
  const { state, dispatch } = useContext(ModalContext);
  const modal = state.modals[0];
  if (!modal) return null;
  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      background: 'rgba(0,0,0,0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 2000,
      animation: 'fadeIn 0.2s ease'
    }} onClick={() => dispatch({ type: 'HIDE_MODAL', payload: modal.id })}>
      <div style={{
        background: 'white',
        borderRadius: 10,
        padding: 20,
        maxWidth: 500,
        width: '90%',
        animation: 'scaleIn 0.2s ease'
      }} onClick={e => e.stopPropagation()}>
        <h3>{modal.title}</h3>
        <p>{modal.content}</p>
        <button onClick={() => dispatch({ type: 'HIDE_MODAL', payload: modal.id })} style={buttonStyle}>Close</button>
      </div>
      <style>{`
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes scaleIn { from { transform: scale(0.9); opacity: 0; } to { transform: scale(1); opacity: 1; } }
      `}</style>
    </div>
  );
}

function Header() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const isOnline = useOnlineStatus();
  const { width } = useWindowSize();
  return (
    <FadeIn>
      <header style={{
        padding: '20px',
        backgroundColor: theme === 'dark' ? '#1a1a2e' : '#f0f0f0',
        color: theme === 'dark' ? '#fff' : '#333',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexWrap: 'wrap',
        gap: '10px'
      }}>
        <div>
          <h1 style={{ margin: 0, fontSize: width < 768 ? '20px' : '28px' }}>
            🚀 ClientLite Ultra Advanced App
          </h1>
          <div style={{ fontSize: '12px', marginTop: '5px' }}>
            Status: {isOnline ? '🟢 Online' : '🔴 Offline'}
          </div>
        </div>
        <div style={{ display: 'flex', gap: '10px' }}>
          <button onClick={toggleTheme} style={{
            padding: '10px 20px',
            cursor: 'pointer',
            borderRadius: '5px',
            border: 'none',
            backgroundColor: theme === 'dark' ? '#0f3460' : '#ddd',
            color: theme === 'dark' ? '#fff' : '#333'
          }}>
            {theme === 'dark' ? '☀️ Light' : '🌙 Dark'}
          </button>
        </div>
      </header>
    </FadeIn>
  );
}

function Counter({ count, onIncrement, onDecrement, step, onStepChange }) {
  // GSAP animation on count change
  const counterRef = useRef(null);
  useEffect(() => {
    if (counterRef.current) {
      gsap.fromTo(counterRef.current, 
        { scale: 1.2, color: '#ff6600' },
        { scale: 1, color: '#ffffff', duration: 0.3, ease: 'back.out' }
      );
    }
  }, [count]);
  
  return (
    <FadeIn delay={100}>
      <div style={cardStyle}>
        <h2 ref={counterRef}>🎯 Counter: {count}</h2>
        <div>
          <label>Step: </label>
          <input
            type="range"
            min="1"
            max="10"
            value={step}
            onChange={(e) => onStepChange(parseInt(e.target.value))}
            style={{ margin: '10px', width: '200px' }}
          />
          <span style={{ marginLeft: '10px' }}>{step}</span>
        </div>
        <div>
          <button onClick={onDecrement} style={{ ...buttonStyle, backgroundColor: '#dc3545' }}>-</button>
          <button onClick={onIncrement} style={{ ...buttonStyle, backgroundColor: '#28a745' }}>+</button>
        </div>
      </div>
    </FadeIn>
  );
}

function UserProfile() {
  const { user, loading, error, fetchUser } = useContext(UserContext);
  const [userId, setUserId] = useLocalStorage('userId', 1);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearch = useDebounce(searchTerm, 500);

  useEffect(() => {
    fetchUser(userId);
  }, [userId, fetchUser]);

  if (loading) return <div style={cardStyle}>⏳ Loading user data...</div>;
  if (error) return <div style={{ ...cardStyle, borderColor: '#dc3545' }}>❌ Error: {error}</div>;
  if (!user) return <div style={cardStyle}>👤 No user data</div>;

  return (
    <FadeIn delay={200}>
      <div style={cardStyle}>
        <h3>👤 User Profile</h3>
        <div style={{ marginBottom: '15px' }}>
          <input
            type="text"
            placeholder="Search in profile..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{ padding: '8px', width: '100%', borderRadius: '5px', border: '1px solid #ccc' }}
          />
        </div>
        <p><strong>Name:</strong> {user.name}</p>
        <p><strong>Email:</strong> {user.email}</p>
        <p><strong>Phone:</strong> {user.phone}</p>
        <p><strong>Website:</strong> {user.website}</p>
        <p><strong>Company:</strong> {user.company?.name}</p>
        <div style={{ display: 'flex', gap: '10px', marginTop: '15px' }}>
          <button onClick={() => setUserId(prev => Math.max(1, prev - 1))} style={buttonStyle}>◀ Previous</button>
          <button onClick={() => setUserId(prev => prev + 1)} style={buttonStyle}>Next ▶</button>
        </div>
        <small style={{ display: 'block', marginTop: '10px' }}>User ID: {userId}</small>
      </div>
    </FadeIn>
  );
}

function TodoList() {
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');
  const [filter, setFilter] = useState('all');
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');
  const inputRef = useRef(null);

  useEffect(() => {
    const savedTodos = localStorage.getItem('todos');
    if (savedTodos) setTodos(JSON.parse(savedTodos));
  }, []);

  useEffect(() => {
    localStorage.setItem('todos', JSON.stringify(todos));
  }, [todos]);

  const addTodo = useCallback(() => {
    if (newTodo.trim()) {
      setTodos([...todos, { id: Date.now(), text: newTodo, completed: false, createdAt: new Date().toISOString() }]);
      setNewTodo('');
    }
  }, [newTodo, todos]);

  const startEdit = useCallback((todo) => {
    setEditingId(todo.id);
    setEditText(todo.text);
    setTimeout(() => inputRef.current?.focus(), 0);
  }, []);

  const saveEdit = useCallback((id) => {
    if (editText.trim()) {
      setTodos(todos.map(todo => todo.id === id ? { ...todo, text: editText } : todo));
      setEditingId(null);
      setEditText('');
    }
  }, [editText, todos]);

  const toggleTodo = useCallback((id) => {
    setTodos(todos.map(todo => todo.id === id ? { ...todo, completed: !todo.completed } : todo));
  }, [todos]);

  const deleteTodo = useCallback((id) => {
    setTodos(todos.filter(todo => todo.id !== id));
  }, [todos]);

  const filteredTodos = useMemo(() => {
    if (filter === 'active') return todos.filter(t => !t.completed);
    if (filter === 'completed') return todos.filter(t => t.completed);
    return todos;
  }, [todos, filter]);

  const stats = useMemo(() => ({
    total: todos.length,
    completed: todos.filter(t => t.completed).length,
    active: todos.filter(t => !t.completed).length,
    completionRate: todos.length ? (todos.filter(t => t.completed).length / todos.length * 100).toFixed(1) : 0
  }), [todos]);

  return (
    <FadeIn delay={300}>
      <div style={cardStyle}>
        <h3>✅ Todo List</h3>
        <div style={{ marginBottom: '15px', background: '#e9ecef', padding: '10px', borderRadius: '5px' }}>
          <div>Progress: {stats.completionRate}%</div>
          <div style={{ background: '#ddd', height: '10px', borderRadius: '5px', overflow: 'hidden', marginTop: '5px' }}>
            <div style={{ width: `${stats.completionRate}%`, background: '#28a745', height: '100%', transition: 'width 0.3s' }} />
          </div>
        </div>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '15px' }}>
          <input
            type="text"
            value={newTodo}
            onChange={(e) => setNewTodo(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTodo()}
            placeholder="Add a new todo..."
            style={{ flex: 1, padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }}
          />
          <button onClick={addTodo} style={buttonStyle}>Add</button>
        </div>
        <div style={{ display: 'flex', gap: '10px', marginBottom: '15px', flexWrap: 'wrap' }}>
          <button onClick={() => setFilter('all')} style={filter === 'all' ? activeButtonStyle : buttonStyle}>All ({stats.total})</button>
          <button onClick={() => setFilter('active')} style={filter === 'active' ? activeButtonStyle : buttonStyle}>Active ({stats.active})</button>
          <button onClick={() => setFilter('completed')} style={filter === 'completed' ? activeButtonStyle : buttonStyle}>Completed ({stats.completed})</button>
        </div>
        <ul style={{ listStyle: 'none', padding: 0 }}>
          {filteredTodos.map(todo => (
            <li key={todo.id} style={{ display: 'flex', alignItems: 'center', gap: '10px', margin: '10px 0', padding: '10px', background: '#f8f9fa', borderRadius: '5px' }}>
              <input type="checkbox" checked={todo.completed} onChange={() => toggleTodo(todo.id)} />
              {editingId === todo.id ? (
                <>
                  <input
                    ref={inputRef}
                    type="text"
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && saveEdit(todo.id)}
                    style={{ flex: 1, padding: '5px' }}
                  />
                  <button onClick={() => saveEdit(todo.id)} style={{ ...buttonStyle, backgroundColor: '#28a745' }}>Save</button>
                  <button onClick={() => setEditingId(null)} style={{ ...buttonStyle, backgroundColor: '#6c757d' }}>Cancel</button>
                </>
              ) : (
                <>
                  <span style={{ flex: 1, textDecoration: todo.completed ? 'line-through' : 'none' }}>{todo.text}</span>
                  <small style={{ fontSize: '10px', color: '#999' }}>{new Date(todo.createdAt).toLocaleDateString()}</small>
                  <button onClick={() => startEdit(todo)} style={{ ...buttonStyle, backgroundColor: '#ffc107', color: '#333' }}>✏️</button>
                  <button onClick={() => deleteTodo(todo.id)} style={{ ...buttonStyle, backgroundColor: '#dc3545' }}>🗑️</button>
                </>
              )}
            </li>
          ))}
        </ul>
        {filteredTodos.length === 0 && <p style={{ textAlign: 'center', color: '#999' }}>No todos yet. Add one above!</p>}
      </div>
    </FadeIn>
  );
}

function ContactForm() {
  const { register, handleSubmit, formState: { errors }, reset } = useForm({
    resolver: zodResolver(contactSchema)
  });

  const onSubmit = (data) => {
    console.log('Form submitted:', data);
    reset();
  };

  return (
    <FadeIn delay={350}>
      <div style={cardStyle}>
        <h3>📧 Contact Form</h3>
        <form onSubmit={handleSubmit(onSubmit)} style={{ display: 'flex', flexDirection: 'column', gap: '15px' }}>
          <div>
            <input {...register('name')} placeholder="Name" style={inputStyle} />
            {errors.name && <span style={{ color: '#dc3545', fontSize: '12px' }}>{errors.name.message}</span>}
          </div>
          <div>
            <input {...register('email')} placeholder="Email" style={inputStyle} />
            {errors.email && <span style={{ color: '#dc3545', fontSize: '12px' }}>{errors.email.message}</span>}
          </div>
          <div>
            <textarea {...register('message')} placeholder="Message" rows="3" style={inputStyle} />
            {errors.message && <span style={{ color: '#dc3545', fontSize: '12px' }}>{errors.message.message}</span>}
          </div>
          <button type="submit" style={buttonStyle}>Send Message</button>
        </form>
      </div>
    </FadeIn>
  );
}

function DataChart() {
  const [chartData] = useState({
    labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July'],
    datasets: [
      {
        label: 'Sales 2024',
        data: [65, 59, 80, 81, 56, 55, 90],
        borderColor: 'rgb(75, 192, 192)',
        backgroundColor: 'rgba(75, 192, 192, 0.2)',
        tension: 0.4
      },
      {
        label: 'Sales 2025',
        data: [45, 69, 70, 91, 66, 75, 110],
        borderColor: 'rgb(255, 99, 132)',
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        tension: 0.4
      }
    ]
  });

  const [barData] = useState({
    labels: ['Product A', 'Product B', 'Product C', 'Product D', 'Product E'],
    datasets: [
      {
        label: 'Units Sold',
        data: [120, 90, 150, 80, 200],
        backgroundColor: 'rgba(54, 162, 235, 0.6)',
        borderColor: 'rgba(54, 162, 235, 1)',
        borderWidth: 1
      }
    ]
  });

  const options = {
    responsive: true,
    maintainAspectRatio: true,
    plugins: {
      legend: { position: 'top' },
      title: { display: true, text: 'Monthly Sales Comparison' }
    }
  };

  return (
    <FadeIn delay={450}>
      <div style={cardStyle}>
        <h3>📈 Sales Charts</h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '20px' }}>
          <div>
            <Line data={chartData} options={options} />
          </div>
          <div>
            <Bar data={barData} options={{ ...options, plugins: { ...options.plugins, title: { display: true, text: 'Product Sales' } } }} />
          </div>
        </div>
      </div>
    </FadeIn>
  );
}

function Footer() {
  const { theme } = useContext(ThemeContext);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [visitorCount, setVisitorCount] = useLocalStorage('visitorCount', 0);

  useEffect(() => {
    setVisitorCount(prev => prev + 1);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <FadeIn delay={500}>
      <footer style={{
        textAlign: 'center',
        padding: '20px',
        backgroundColor: theme === 'dark' ? '#1a1a2e' : '#e9ecef',
        marginTop: '20px'
      }}>
        <p>⚡ ClientLite Ultra Framework | Built with React + JSX</p>
        <p>🕐 {currentTime.toLocaleString()}</p>
        <p>👁️ Visitors: {visitorCount}</p>
      </footer>
    </FadeIn>
  );
}

// ==================== STYLES ====================
const buttonStyle = {
  padding: '8px 16px',
  margin: '3px',
  cursor: 'pointer',
  borderRadius: '5px',
  border: 'none',
  backgroundColor: '#007bff',
  color: 'white',
  transition: 'all 0.2s'
};

const activeButtonStyle = {
  ...buttonStyle,
  backgroundColor: '#28a745'
};

const cardStyle = {
  backgroundColor: 'white',
  borderRadius: '8px',
  padding: '20px',
  margin: '20px',
  boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
  transition: 'transform 0.2s, box-shadow 0.2s'
};

const inputStyle = {
  width: '100%',
  padding: '10px',
  borderRadius: '5px',
  border: '1px solid #ccc',
  fontSize: '14px'
};

// ==================== MAIN APP ====================
function App() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [theme, setTheme] = useLocalStorage('theme', 'light');
  const [userState, setUserState] = useState({ user: null, loading: false, error: null });
  const { width } = useWindowSize();

  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');

  const fetchUser = useCallback(async (id) => {
    setUserState({ user: null, loading: true, error: null });
    try {
      const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`);
      if (!response.ok) throw new Error('Failed to fetch user');
      const user = await response.json();
      setUserState({ user, loading: false, error: null });
      dispatch({ type: 'ADD_NOTIFICATION', payload: { id: Date.now(), message: `Loaded user: ${user.name}`, type: 'success' } });
    } catch (error) {
      setUserState({ user: null, loading: false, error: error.message });
      dispatch({ type: 'ADD_NOTIFICATION', payload: { id: Date.now(), message: error.message, type: 'error' } });
    }
  }, []);

  const increment = () => dispatch({ type: 'INCREMENT' });
  const decrement = () => dispatch({ type: 'DECREMENT' });
  const setStep = (step) => dispatch({ type: 'SET_STEP', payload: step });

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <UserContext.Provider value={{ ...userState, fetchUser }}>
        <NotificationContext.Provider value={{ state, dispatch }}>
          <ModalContext.Provider value={{ state, dispatch }}>
            <ThreeDBackground />
            <Notifications />
            <Modal />
            <div style={{
              minHeight: '100vh',
              backgroundColor: 'transparent',
              color: theme === 'dark' ? '#fff' : '#333',
              position: 'relative',
              zIndex: 1
            }}>
              <Header />
              <div style={{ maxWidth: width < 768 ? '100%' : '1200px', margin: '0 auto', padding: '20px' }}>
                <div style={{ display: 'grid', gridTemplateColumns: width < 1024 ? '1fr' : 'repeat(auto-fit, minmax(400px, 1fr))', gap: '20px' }}>
                  <Counter count={state.count} onIncrement={increment} onDecrement={decrement} step={state.step} onStepChange={setStep} />
                  <UserProfile />
                </div>
                <TodoList />
                <ContactForm />
                <DataChart />
              </div>
              <Footer />
            </div>
          </ModalContext.Provider>
        </NotificationContext.Provider>
      </UserContext.Provider>
    </ThemeContext.Provider>
  );
}

// ==================== MOUNT APP ====================
const root = createRoot(document.getElementById('root'));
root.render(<App />);