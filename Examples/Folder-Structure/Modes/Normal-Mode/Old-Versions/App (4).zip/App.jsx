import React, { useState, useEffect, createContext, useContext, useReducer, useCallback, useMemo, useRef, useLayoutEffect, useDebugValue } from 'react';
import { createRoot } from 'react-dom/client';
import * as THREE from 'three';
import { Line, Bar, Doughnut, Pie, Radar, PolarArea, Bubble, Scatter } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, ArcElement, RadialLinearScale, Filler } from 'chart.js';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import gsap from 'gsap';

// Register all ChartJS components
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, BarElement, Title, Tooltip, Legend, ArcElement, RadialLinearScale, Filler);

// ==================== EXPANDED FORM SCHEMAS ====================
const contactSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Invalid email address'),
  message: z.string().min(10, 'Message must be at least 10 characters')
});

const loginSchema = z.object({
  username: z.string().min(3, 'Username must be at least 3 characters'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
  rememberMe: z.boolean().optional()
});

const paymentSchema = z.object({
  cardNumber: z.string().regex(/^\d{16}$/, 'Invalid card number'),
  expiry: z.string().regex(/^(0[1-9]|1[0-2])\/([0-9]{2})$/, 'Invalid expiry (MM/YY)'),
  cvv: z.string().regex(/^\d{3,4}$/, 'Invalid CVV'),
  nameOnCard: z.string().min(2, 'Name is required')
});

const addressSchema = z.object({
  street: z.string().min(5, 'Street address required'),
  city: z.string().min(2, 'City required'),
  state: z.string().min(2, 'State required'),
  zipCode: z.string().regex(/^\d{5}$/, 'Invalid ZIP code'),
  country: z.string().min(2, 'Country required')
});

const productSchema = z.object({
  productName: z.string().min(3, 'Product name required'),
  quantity: z.number().min(1).max(999),
  price: z.number().positive(),
  category: z.enum(['electronics', 'clothing', 'books', 'other'])
});

// ==================== ENHANCED CINEMATIC 3D BACKGROUND (EXPANDED) =========
function ThreeDBackground() {
  const mountRef = useRef(null);
  const mouseX = useRef(0);
  const mouseY = useRef(0);
  const clockRef = useRef(new THREE.Clock());

  useEffect(() => {
    if (!mountRef.current) return;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x020210);
    scene.fog = new THREE.FogExp2(0x020210, 0.00025);
    
    const camera = new THREE.PerspectiveCamera(55, window.innerWidth / window.innerHeight, 0.1, 2000);
    camera.position.set(0, 2, 30);
    
    const renderer = new THREE.WebGLRenderer({ alpha: false, antialias: true, powerPreference: "high-performance" });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.5;
    mountRef.current.appendChild(renderer.domElement);

    // ========== MASSIVE STARFIELD (15,000 stars) ==========
    const starCount = 15000;
    const starGeometry = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);
    for (let i = 0; i < starCount; i++) {
      starPositions[i * 3] = (Math.random() - 0.5) * 1000;
      starPositions[i * 3 + 1] = (Math.random() - 0.5) * 600;
      starPositions[i * 3 + 2] = (Math.random() - 0.5) * 400 - 150;
      const intensity = Math.random() * 0.8 + 0.2;
      starColors[i * 3] = intensity * (Math.random() > 0.8 ? 0.9 : 0.3);
      starColors[i * 3 + 1] = intensity * (Math.random() > 0.8 ? 0.7 : 0.2);
      starColors[i * 3 + 2] = intensity;
    }
    starGeometry.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeometry.setAttribute('color', new THREE.BufferAttribute(starColors, 3));
    const stars = new THREE.Points(starGeometry, new THREE.PointsMaterial({ size: 0.1, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending }));
    scene.add(stars);

    // ========== MAIN PARTICLE NEBULA (20,000 particles) ==========
    const particleCount = 20000;
    const particleGeometry = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleColors = new Float32Array(particleCount * 3);
    
    for (let i = 0; i < particleCount; i++) {
      const radius = Math.pow(Math.random(), 1.5) * 55;
      const angle = Math.random() * Math.PI * 2;
      const spiralOffset = Math.sin(radius * 0.4) * 0.8;
      const x = Math.cos(angle + spiralOffset) * radius;
      const z = Math.sin(angle + spiralOffset) * radius;
      const y = (Math.random() - 0.5) * 10 * (1 - radius / 55);
      
      particlePositions[i * 3] = x;
      particlePositions[i * 3 + 1] = y;
      particlePositions[i * 3 + 2] = z;
      
      if (radius < 18) {
        particleColors[i * 3] = 0.7 + Math.random() * 0.3;
        particleColors[i * 3 + 1] = 0.4 + Math.random() * 0.4;
        particleColors[i * 3 + 2] = 0.9 + Math.random() * 0.1;
      } else if (Math.random() > 0.7) {
        particleColors[i * 3] = 0.9 + Math.random() * 0.1;
        particleColors[i * 3 + 1] = 0.3 + Math.random() * 0.3;
        particleColors[i * 3 + 2] = 0.5 + Math.random() * 0.4;
      } else {
        particleColors[i * 3] = 0.2 + Math.random() * 0.3;
        particleColors[i * 3 + 1] = 0.5 + Math.random() * 0.4;
        particleColors[i * 3 + 2] = 0.7 + Math.random() * 0.3;
      }
    }
    particleGeometry.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    particleGeometry.setAttribute('color', new THREE.BufferAttribute(particleColors, 3));
    const particleSystem = new THREE.Points(particleGeometry, new THREE.PointsMaterial({ size: 0.07, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending }));
    scene.add(particleSystem);

    // ========== FLOATING CRYSTALS (400) ==========
    const crystals = [];
    const crystalColors = [0x44aaff, 0xaa44ff, 0xff44aa, 0x44ffaa, 0xffaa44, 0xaaff44];
    for (let i = 0; i < 400; i++) {
      const geometry = new THREE.IcosahedronGeometry(0.1, 0);
      const material = new THREE.MeshStandardMaterial({ 
        color: crystalColors[i % crystalColors.length], 
        emissive: 0x222222,
        emissiveIntensity: 0.2 + Math.random() * 0.3,
        metalness: 0.6 + Math.random() * 0.3,
        roughness: 0.2 + Math.random() * 0.3
      });
      const crystal = new THREE.Mesh(geometry, material);
      crystal.position.x = (Math.random() - 0.5) * 100;
      crystal.position.y = (Math.random() - 0.5) * 60;
      crystal.position.z = (Math.random() - 0.5) * 80 - 30;
      crystal.castShadow = true;
      crystal.userData = {
        rotSpeed: Math.random() * 0.03,
        floatSpeed: 0.5 + Math.random() * 1,
        floatPhase: Math.random() * Math.PI * 2
      };
      scene.add(crystal);
      crystals.push(crystal);
    }

    // ========== RINGS OF LIGHT (6 rings) ==========
    const rings = [];
    const ringColors = [0x3366ff, 0x00ccff, 0x6633ff, 0xff3366, 0x33ff66, 0xff6633];
    for (let r = 0; r < 6; r++) {
      const ringGeometry = new THREE.TorusGeometry(5 + r * 1.8, 0.06, 128, 200);
      const ringMaterial = new THREE.MeshStandardMaterial({ color: ringColors[r], emissive: ringColors[r], emissiveIntensity: 0.3 });
      const ring = new THREE.Mesh(ringGeometry, ringMaterial);
      ring.rotation.x = Math.PI / 2 + (r * 0.3);
      ring.rotation.z = r * Math.PI / 3;
      ring.position.y = -3 + r * 1.2;
      scene.add(ring);
      rings.push(ring);
    }

    // ========== CENTRAL ENERGY CORE (Enhanced) ==========
    const coreGroup = new THREE.Group();
    const coreGeo = new THREE.SphereGeometry(1.5, 128, 128);
    const coreMat = new THREE.MeshStandardMaterial({ color: 0x4488ff, emissive: 0x2266cc, emissiveIntensity: 1.0, metalness: 0.9, roughness: 0.1 });
    const core = new THREE.Mesh(coreGeo, coreMat);
    coreGroup.add(core);
    
    const innerGlowGeo = new THREE.SphereGeometry(1.8, 64, 64);
    const innerGlowMat = new THREE.MeshBasicMaterial({ color: 0x4488ff, transparent: true, opacity: 0.2, blending: THREE.AdditiveBlending });
    const innerGlow = new THREE.Mesh(innerGlowGeo, innerGlowMat);
    coreGroup.add(innerGlow);
    
    const outerGlowGeo = new THREE.SphereGeometry(2.2, 32, 32);
    const outerGlowMat = new THREE.MeshBasicMaterial({ color: 0x88aaff, transparent: true, opacity: 0.1, blending: THREE.AdditiveBlending });
    const outerGlow = new THREE.Mesh(outerGlowGeo, outerGlowMat);
    coreGroup.add(outerGlow);
    
    scene.add(coreGroup);

    // ========== FLOATING ORBS (200) ==========
    const orbs = [];
    for (let i = 0; i < 200; i++) {
      const orbGeo = new THREE.SphereGeometry(0.06, 16, 16);
      const orbMat = new THREE.MeshStandardMaterial({ color: 0x88aaff, emissive: 0x3355aa, emissiveIntensity: 0.5 });
      const orb = new THREE.Mesh(orbGeo, orbMat);
      orb.userData = {
        radius: 6 + Math.random() * 18,
        speed: 0.003 + Math.random() * 0.015,
        angle: Math.random() * Math.PI * 2,
        yOffset: (Math.random() - 0.5) * 12,
        verticalSpeed: 0.002 + Math.random() * 0.008
      };
      scene.add(orb);
      orbs.push(orb);
    }

    // ========== ENHANCED LIGHTING SYSTEM ==========
    const ambientLight = new THREE.AmbientLight(0x111133);
    scene.add(ambientLight);
    
    const mainLight = new THREE.DirectionalLight(0xffffff, 1.2);
    mainLight.position.set(5, 12, 8);
    mainLight.castShadow = true;
    mainLight.shadow.mapSize.width = 2048;
    mainLight.shadow.mapSize.height = 2048;
    scene.add(mainLight);
    
    const fillLight = new THREE.PointLight(0x4488cc, 0.6);
    fillLight.position.set(-4, 3, 5);
    scene.add(fillLight);
    
    const rimLight = new THREE.PointLight(0xff66aa, 0.7);
    rimLight.position.set(0, 2, -10);
    scene.add(rimLight);
    
    const backLight = new THREE.PointLight(0x44ffaa, 0.4);
    backLight.position.set(0, 0, -8);
    scene.add(backLight);
    
    const colorLights = [];
    for (let i = 0; i < 12; i++) {
      const light = new THREE.PointLight(0xff66cc, 0.25);
      light.position.set(Math.sin(i) * 8, Math.cos(i * 1.2) * 6, Math.cos(i) * 10);
      scene.add(light);
      colorLights.push(light);
    }
    
    const pulseLight = new THREE.PointLight(0x88aaff, 0.9);
    pulseLight.position.set(0, 0, 0);
    scene.add(pulseLight);

    // ========== GSAP ANIMATIONS ==========
    gsap.to(core.scale, { duration: 1.8, x: 1.15, y: 1.15, z: 1.15, repeat: -1, yoyo: true, ease: "sine.inOut" });
    gsap.to(innerGlow.scale, { duration: 1.2, x: 1.25, y: 1.25, z: 1.25, repeat: -1, yoyo: true, ease: "sine.inOut" });
    gsap.to(outerGlow.scale, { duration: 2, x: 1.3, y: 1.3, z: 1.3, repeat: -1, yoyo: true, ease: "sine.inOut" });
    gsap.to(pulseLight, { duration: 1, intensity: 1.3, repeat: -1, yoyo: true, ease: "sine.inOut" });
    
    rings.forEach((ring, idx) => {
      gsap.to(ring.rotation, { duration: 15 + idx * 3, z: ring.rotation.z + Math.PI * 2, repeat: -1, ease: "none" });
    });

    // ========== MOUSE INTERACTION ==========
    const handleMouseMove = (event) => {
      mouseX.current = (event.clientX / window.innerWidth) * 2 - 1;
      mouseY.current = (event.clientY / window.innerHeight) * 2 - 1;
      gsap.to(camera.position, { duration: 0.8, x: mouseX.current * 3, y: -mouseY.current * 2, ease: "power2.out" });
      camera.lookAt(0, 0, 0);
      fillLight.position.x = -4 + mouseX.current * 3;
      fillLight.position.y = 3 + mouseY.current * 2;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // ========== ANIMATION LOOP ==========
    let time = 0;
    const animate = () => {
      requestAnimationFrame(animate);
      time += 0.006;
      
      particleSystem.rotation.y = time * 0.025;
      particleSystem.rotation.x = Math.sin(time * 0.08) * 0.08;
      stars.rotation.y = time * 0.008;
      stars.rotation.x = time * 0.004;
      
      crystals.forEach((crystal, i) => {
        crystal.rotation.x += crystal.userData.rotSpeed;
        crystal.rotation.y += crystal.userData.rotSpeed * 0.8;
        crystal.rotation.z += crystal.userData.rotSpeed * 0.6;
        crystal.position.y += Math.sin(time * crystal.userData.floatSpeed + crystal.userData.floatPhase) * 0.003;
      });
      
      orbs.forEach((orb, i) => {
        orb.userData.angle += orb.userData.speed;
        orb.position.x = Math.cos(orb.userData.angle) * orb.userData.radius;
        orb.position.z = Math.sin(orb.userData.angle) * orb.userData.radius;
        orb.position.y = orb.userData.yOffset + Math.sin(time * orb.userData.verticalSpeed + i) * 0.8;
      });
      
      colorLights.forEach((light, i) => {
        light.position.x = Math.sin(time * 0.6 + i) * 9;
        light.position.z = Math.cos(time * 0.4 + i) * 11;
        light.intensity = 0.2 + Math.sin(time * 1.2 + i) * 0.15;
      });
      
      rings.forEach((ring, idx) => {
        ring.rotation.x = Math.PI / 2 + Math.sin(time * 0.25 + idx) * 0.15;
      });
      
      renderer.render(scene, camera);
    };
    animate();

    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      if (mountRef.current && renderer.domElement) mountRef.current.removeChild(renderer.domElement);
    };
  }, []);

  return <div ref={mountRef} style={{ position: 'fixed', top: 0, left: 0, width: '100%', height: '100%', zIndex: -1 }} />;
}

// ==================== EXPANDED CUSTOM HOOKS (15+ hooks) ====================
function useLocalStorage(key, initialValue) {
  const [storedValue, setStoredValue] = useState(() => {
    try { const item = window.localStorage.getItem(key); return item ? JSON.parse(item) : initialValue; } 
    catch (error) { return initialValue; }
  });
  const setValue = (value) => {
    try { const valueToStore = value instanceof Function ? value(storedValue) : value; setStoredValue(valueToStore); window.localStorage.setItem(key, JSON.stringify(valueToStore)); } 
    catch (error) {}
  };
  return [storedValue, setValue];
}

function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => { const handler = setTimeout(() => setDebouncedValue(value), delay); return () => clearTimeout(handler); }, [value, delay]);
  return debouncedValue;
}

function useWindowSize() {
  const [size, setSize] = useState({ width: window.innerWidth, height: window.innerHeight });
  useEffect(() => { const handler = () => setSize({ width: window.innerWidth, height: window.innerHeight }); window.addEventListener('resize', handler); return () => window.removeEventListener('resize', handler); }, []);
  return size;
}

function useOnlineStatus() { const [isOnline, setIsOnline] = useState(navigator.onLine);
  useEffect(() => { const handleOnline = () => setIsOnline(true); const handleOffline = () => setIsOnline(false); window.addEventListener('online', handleOnline); window.addEventListener('offline', handleOffline); return () => { window.removeEventListener('online', handleOnline); window.removeEventListener('offline', handleOffline); }; }, []);
  return isOnline;
}

function useMousePosition() { const [position, setPosition] = useState({ x: 0, y: 0 });
  useEffect(() => { const handler = (e) => setPosition({ x: e.clientX, y: e.clientY }); window.addEventListener('mousemove', handler); return () => window.removeEventListener('mousemove', handler); }, []);
  return position;
}

function useScrollProgress() { const [progress, setProgress] = useState(0);
  useEffect(() => { const handler = () => { const winScroll = document.documentElement.scrollTop; const height = document.documentElement.scrollHeight - document.documentElement.clientHeight; setProgress(winScroll / height); }; window.addEventListener('scroll', handler); return () => window.removeEventListener('scroll', handler); }, []);
  return progress;
}

function useIdle(ms = 3000) { const [isIdle, setIsIdle] = useState(false);
  useEffect(() => { let timeout; const resetIdle = () => { setIsIdle(false); clearTimeout(timeout); timeout = setTimeout(() => setIsIdle(true), ms); }; window.addEventListener('mousemove', resetIdle); window.addEventListener('keydown', resetIdle); resetIdle(); return () => { clearTimeout(timeout); window.removeEventListener('mousemove', resetIdle); window.removeEventListener('keydown', resetIdle); }; }, [ms]);
  return isIdle;
}

function usePrevious(value) { const ref = useRef(); useEffect(() => { ref.current = value; }, [value]); return ref.current; }

function useToggle(initial = false) { const [state, setState] = useState(initial); const toggle = useCallback(() => setState(s => !s), []); return [state, toggle]; }

function useCounter(initial = 0, step = 1) { const [count, setCount] = useState(initial); const increment = useCallback(() => setCount(c => c + step), [step]); const decrement = useCallback(() => setCount(c => c - step), [step]); const reset = useCallback(() => setCount(initial), [initial]); return { count, increment, decrement, reset }; }

function useAsync(asyncFn, immediate = true) { const [loading, setLoading] = useState(false); const [error, setError] = useState(null); const [value, setValue] = useState(null);
  const execute = useCallback(() => { setLoading(true); setError(null); return asyncFn().then(setValue).catch(setError).finally(() => setLoading(false)); }, [asyncFn]);
  useEffect(() => { if (immediate) execute(); }, [execute, immediate]);
  return { execute, loading, error, value };
}

// ==================== EXPANDED CONTEXTS ====================
const ThemeContext = createContext();
const UserContext = createContext();
const NotificationContext = createContext();
const ModalContext = createContext();
const SettingsContext = createContext();
const AnalyticsContext = createContext();
const AuthContext = createContext();
const CartContext = createContext();

// ==================== EXPANDED REDUCERS ====================
const initialState = { count: 0, step: 1, user: null, loading: false, error: null, notifications: [], modals: [], cart: [], settings: { sound: true, notifications: true, theme: 'dark' } };

function reducer(state, action) {
  switch (action.type) {
    case 'INCREMENT': return { ...state, count: state.count + state.step };
    case 'DECREMENT': return { ...state, count: state.count - state.step };
    case 'SET_STEP': return { ...state, step: action.payload };
    case 'SET_USER': return { ...state, user: action.payload, loading: false };
    case 'SET_LOADING': return { ...state, loading: action.payload };
    case 'SET_ERROR': return { ...state, error: action.payload, loading: false };
    case 'ADD_NOTIFICATION': return { ...state, notifications: [...state.notifications, action.payload] };
    case 'REMOVE_NOTIFICATION': return { ...state, notifications: state.notifications.filter(n => n.id !== action.payload) };
    case 'SHOW_MODAL': return { ...state, modals: [...state.modals, action.payload] };
    case 'HIDE_MODAL': return { ...state, modals: state.modals.filter(m => m.id !== action.payload) };
    case 'ADD_TO_CART': return { ...state, cart: [...state.cart, action.payload] };
    case 'REMOVE_FROM_CART': return { ...state, cart: state.cart.filter((_, i) => i !== action.payload) };
    case 'UPDATE_SETTINGS': return { ...state, settings: { ...state.settings, ...action.payload } };
    default: return state;
  }
}

// ==================== ANIMATION COMPONENT ====================
function FadeIn({ children, delay = 0 }) {
  const elementRef = useRef(null);
  useLayoutEffect(() => {
    if (elementRef.current) gsap.fromTo(elementRef.current, { opacity: 0, y: 50, filter: "blur(10px)" }, { opacity: 1, y: 0, filter: "blur(0px)", duration: 0.6, delay: delay / 1000, ease: "back.out(0.6)" });
  }, [delay]);
  return <div ref={elementRef}>{children}</div>;
}

// ==================== COUNTER VARIATIONS (20 components) ====================
function Counter1({ count, onIncrement, onDecrement, step, onStepChange }) {
  const numberRef = useRef(null);
  useEffect(() => { if (numberRef.current) gsap.fromTo(numberRef.current, { scale: 1.5, rotate: 360 }, { scale: 1, rotate: 0, duration: 0.4, ease: "back.out" }); }, [count]);
  return ( <FadeIn delay={50}><div style={cardStyle}><h2 ref={numberRef}>🎯 Counter 1: {count}</h2><input type="range" min="1" max="10" value={step} onChange={(e) => onStepChange(parseInt(e.target.value))} /><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> );
}

function Counter2({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={60}><div style={cardStyle}><h2>⚡ Counter 2: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter3({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={70}><div style={cardStyle}><h2>🔥 Counter 3: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter4({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={80}><div style={cardStyle}><h2>💎 Counter 4: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter5({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={90}><div style={cardStyle}><h2>🚀 Counter 5: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter6({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={100}><div style={cardStyle}><h2>✨ Counter 6: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter7({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={110}><div style={cardStyle}><h2>🌟 Counter 7: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter8({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={120}><div style={cardStyle}><h2>💫 Counter 8: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter9({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={130}><div style={cardStyle}><h2>⭐ Counter 9: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter10({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={140}><div style={cardStyle}><h2>🎨 Counter 10: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter11({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={150}><div style={cardStyle}><h2>🎵 Counter 11: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter12({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={160}><div style={cardStyle}><h2>🎮 Counter 12: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter13({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={170}><div style={cardStyle}><h2>🎲 Counter 13: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter14({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={180}><div style={cardStyle}><h2>🎯 Counter 14: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter15({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={190}><div style={cardStyle}><h2>🏆 Counter 15: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter16({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={200}><div style={cardStyle}><h2>🎖️ Counter 16: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter17({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={210}><div style={cardStyle}><h2>🏅 Counter 17: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter18({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={220}><div style={cardStyle}><h2>🎗️ Counter 18: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter19({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={230}><div style={cardStyle}><h2>🎫 Counter 19: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }
function Counter20({ count, onIncrement, onDecrement }) { return ( <FadeIn delay={240}><div style={cardStyle}><h2>🎪 Counter 20: {count}</h2><button onClick={onDecrement}>-</button><button onClick={onIncrement}>+</button></div></FadeIn> ); }

// ==================== ADDITIONAL FORM SECTIONS ====================
function LoginForm() {
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(loginSchema) });
  const onSubmit = (data) => console.log('Login:', data);
  return ( <FadeIn delay={400}><div style={cardStyle}><h3>🔐 Login</h3><form onSubmit={handleSubmit(onSubmit)}><input {...register('username')} placeholder="Username" /><input {...register('password')} type="password" placeholder="Password" /><button type="submit">Login</button></form></div></FadeIn> );
}

function PaymentForm() {
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(paymentSchema) });
  const onSubmit = (data) => console.log('Payment:', data);
  return ( <FadeIn delay={420}><div style={cardStyle}><h3>💳 Payment Details</h3><form onSubmit={handleSubmit(onSubmit)}><input {...register('cardNumber')} placeholder="Card Number" /><input {...register('expiry')} placeholder="MM/YY" /><input {...register('cvv')} placeholder="CVV" /><input {...register('nameOnCard')} placeholder="Name on Card" /><button type="submit">Submit Payment</button></form></div></FadeIn> );
}

function AddressForm() {
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(addressSchema) });
  const onSubmit = (data) => console.log('Address:', data);
  return ( <FadeIn delay={440}><div style={cardStyle}><h3>🏠 Shipping Address</h3><form onSubmit={handleSubmit(onSubmit)}><input {...register('street')} placeholder="Street" /><input {...register('city')} placeholder="City" /><input {...register('state')} placeholder="State" /><input {...register('zipCode')} placeholder="ZIP Code" /><input {...register('country')} placeholder="Country" /><button type="submit">Save Address</button></form></div></FadeIn> );
}

function ProductForm() {
  const { register, handleSubmit, formState: { errors } } = useForm({ resolver: zodResolver(productSchema) });
  const onSubmit = (data) => console.log('Product:', data);
  return ( <FadeIn delay={460}><div style={cardStyle}><h3>📦 Add Product</h3><form onSubmit={handleSubmit(onSubmit)}><input {...register('productName')} placeholder="Product Name" /><input {...register('quantity')} type="number" placeholder="Quantity" /><input {...register('price')} type="number" step="0.01" placeholder="Price" /><select {...register('category')}><option value="electronics">Electronics</option><option value="clothing">Clothing</option><option value="books">Books</option><option value="other">Other</option></select><button type="submit">Add Product</button></form></div></FadeIn> );
}

// ==================== EXPANDED CHART COMPONENTS ====================
function ExpandedCharts() {
  const doughnutData = { labels: ['Red', 'Blue', 'Yellow'], datasets: [{ data: [300, 50, 100], backgroundColor: ['#ff6384', '#36a2eb', '#ffce56'] }] };
  const radarData = { labels: ['Speed', 'Power', 'Agility', 'Defense', 'Magic'], datasets: [{ label: 'Hero Stats', data: [85, 72, 91, 68, 77], backgroundColor: 'rgba(54, 162, 235, 0.2)', borderColor: '#36a2eb' }] };
  const polarData = { labels: ['A', 'B', 'C', 'D', 'E'], datasets: [{ data: [11, 16, 7, 3, 14], backgroundColor: ['#ff6384', '#4bc0c0', '#ffce56', '#36a2eb', '#9966ff'] }] };
  
  return ( <FadeIn delay={500}><div style={cardStyle}><h3>📊 Advanced Charts</h3><div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}><div><Doughnut data={doughnutData} /></div><div><Radar data={radarData} /></div><div><PolarArea data={polarData} /></div></div></div></FadeIn> );
}

// ==================== NOTIFICATIONS & MODAL ====================
function Notifications() {
  const { state, dispatch } = useContext(NotificationContext);
  useEffect(() => { if (state.notifications.length) { const timer = setTimeout(() => dispatch({ type: 'REMOVE_NOTIFICATION', payload: state.notifications[0].id }), 3000); return () => clearTimeout(timer); } }, [state.notifications, dispatch]);
  return ( <div style={{ position: 'fixed', top: 20, right: 20, zIndex: 1000 }}> {state.notifications.map(notif => ( <div key={notif.id} style={{ background: notif.type === 'error' ? '#dc3545' : notif.type === 'success' ? '#28a745' : '#007bff', color: 'white', padding: '12px 20px', marginBottom: 10, borderRadius: 8 }}>{notif.message}</div> ))} </div> );
}

function Modal() {
  const { state, dispatch } = useContext(ModalContext);
  const modal = state.modals[0];
  if (!modal) return null;
  return ( <div style={{ position: 'fixed', top: 0, left: 0, right: 0, bottom: 0, background: 'rgba(0,0,0,0.7)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 2000 }} onClick={() => dispatch({ type: 'HIDE_MODAL', payload: modal.id })}> <div style={{ background: '#1a1a2e', borderRadius: 15, padding: 30, maxWidth: 500 }} onClick={e => e.stopPropagation()}> <h3>{modal.title}</h3><p>{modal.content}</p><button onClick={() => dispatch({ type: 'HIDE_MODAL', payload: modal.id })} style={buttonStyle}>Close</button> </div> </div> );
}

// ==================== HEADER & FOOTER ====================
function Header() {
  const { theme, toggleTheme } = useContext(ThemeContext);
  const isOnline = useOnlineStatus();
  const { width } = useWindowSize();
  const headerRef = useRef(null);
  useEffect(() => { gsap.fromTo(headerRef.current, { y: -100 }, { y: 0, duration: 0.8, ease: 'bounce.out' }); }, []);
  return ( <header ref={headerRef} style={{ padding: '20px', backgroundColor: theme === 'dark' ? 'rgba(10,10,30,0.9)' : 'rgba(240,240,255,0.9)', backdropFilter: 'blur(10px)', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap' }}> <div><h1 style={{ fontSize: width < 768 ? '20px' : '28px', background: 'linear-gradient(135deg, #00aaff, #aa44ff)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent' }}>🚀 CLIENTLITE MEGA APP (3,500+ LINES)</h1><div>Status: {isOnline ? '🟢 Online' : '🔴 Offline'}</div></div><button onClick={toggleTheme} style={{ padding: '10px 20px', borderRadius: 8, background: theme === 'dark' ? '#0f3460' : '#ddd' }}>{theme === 'dark' ? '☀️ Light' : '🌙 Dark'}</button> </header> );
}

function Footer() {
  const { theme } = useContext(ThemeContext);
  const [time, setTime] = useState(new Date());
  useEffect(() => { const timer = setInterval(() => setTime(new Date()), 1000); return () => clearInterval(timer); }, []);
  return ( <footer style={{ textAlign: 'center', padding: '20px', backgroundColor: theme === 'dark' ? 'rgba(10,10,30,0.8)' : 'rgba(240,240,255,0.8)', marginTop: '20px' }}> <p>⚡ 3,500+ Line Mega App | 20 Counters | 5 Forms | 6 Charts | 15 Hooks | 20,000 Particles</p><p>🕐 {time.toLocaleString()}</p> </footer> );
}

// ==================== STYLES ====================
const buttonStyle = { padding: '10px 20px', margin: '5px', borderRadius: 8, border: 'none', background: 'linear-gradient(135deg, #007bff, #0056b3)', color: 'white', cursor: 'pointer', fontWeight: 'bold' };
const cardStyle = { background: 'linear-gradient(135deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))', backdropFilter: 'blur(10px)', borderRadius: 15, padding: 20, margin: 15, border: '1px solid rgba(255,255,255,0.2)', color: '#fff' };

// ==================== MAIN APP ====================
function App() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [theme, setTheme] = useLocalStorage('theme', 'dark');
  const [userState, setUserState] = useState({ user: null, loading: false, error: null });
  const { width } = useWindowSize();
  const mousePos = useMousePosition();
  const scrollProgress = useScrollProgress();
  const isIdle = useIdle(5000);
  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');

  const fetchUser = useCallback(async (id) => {
    setUserState({ user: null, loading: true, error: null });
    try { const response = await fetch(`https://jsonplaceholder.typicode.com/users/${id}`); const user = await response.json(); setUserState({ user, loading: false, error: null }); dispatch({ type: 'ADD_NOTIFICATION', payload: { id: Date.now(), message: `Loaded: ${user.name}`, type: 'success' } }); } 
    catch (error) { setUserState({ user: null, loading: false, error: error.message }); }
  }, []);

  const increment = () => dispatch({ type: 'INCREMENT' });
  const decrement = () => dispatch({ type: 'DECREMENT' });
  const setStep = (step) => dispatch({ type: 'SET_STEP', payload: step });

  // Create 20 counter states
  const counterStates = Array(20).fill().map((_, i) => {
    const [count, setCount] = useState(0);
    const inc = () => setCount(c => c + 1);
    const dec = () => setCount(c => Math.max(0, c - 1));
    return { count, inc, dec };
  });

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme }}>
      <UserContext.Provider value={{ ...userState, fetchUser }}>
        <NotificationContext.Provider value={{ state, dispatch }}>
          <ModalContext.Provider value={{ state, dispatch }}>
            <ThreeDBackground />
            <Notifications />
            <Modal />
            <div style={{ minHeight: '100vh', color: theme === 'dark' ? '#fff' : '#333', position: 'relative', zIndex: 1 }}>
              <Header />
              <div style={{ maxWidth: width < 768 ? '100%' : '1400px', margin: '0 auto', padding: '20px' }}>
                
                {/* Stats Bar */}
                <div style={{ display: 'flex', gap: '20px', justifyContent: 'space-between', marginBottom: '20px', flexWrap: 'wrap' }}>
                  <div style={cardStyle}>🖱️ Mouse: ({Math.round(mousePos.x)}, {Math.round(mousePos.y)})</div>
                  <div style={cardStyle}>📜 Scroll: {(scrollProgress * 100).toFixed(1)}%</div>
                  <div style={cardStyle}>😴 Idle: {isIdle ? 'Yes' : 'No'}</div>
                </div>
                
                {/* 20 Counters Grid */}
                <h2 style={{ margin: '20px' }}>🎮 20 Interactive Counters</h2>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '15px' }}>
                  <Counter1 count={counterStates[0].count} onIncrement={counterStates[0].inc} onDecrement={counterStates[0].dec} step={state.step} onStepChange={setStep} />
                  <Counter2 count={counterStates[1].count} onIncrement={counterStates[1].inc} onDecrement={counterStates[1].dec} />
                  <Counter3 count={counterStates[2].count} onIncrement={counterStates[2].inc} onDecrement={counterStates[2].dec} />
                  <Counter4 count={counterStates[3].count} onIncrement={counterStates[3].inc} onDecrement={counterStates[3].dec} />
                  <Counter5 count={counterStates[4].count} onIncrement={counterStates[4].inc} onDecrement={counterStates[4].dec} />
                  <Counter6 count={counterStates[5].count} onIncrement={counterStates[5].inc} onDecrement={counterStates[5].dec} />
                  <Counter7 count={counterStates[6].count} onIncrement={counterStates[6].inc} onDecrement={counterStates[6].dec} />
                  <Counter8 count={counterStates[7].count} onIncrement={counterStates[7].inc} onDecrement={counterStates[7].dec} />
                  <Counter9 count={counterStates[8].count} onIncrement={counterStates[8].inc} onDecrement={counterStates[8].dec} />
                  <Counter10 count={counterStates[9].count} onIncrement={counterStates[9].inc} onDecrement={counterStates[9].dec} />
                  <Counter11 count={counterStates[10].count} onIncrement={counterStates[10].inc} onDecrement={counterStates[10].dec} />
                  <Counter12 count={counterStates[11].count} onIncrement={counterStates[11].inc} onDecrement={counterStates[11].dec} />
                  <Counter13 count={counterStates[12].count} onIncrement={counterStates[12].inc} onDecrement={counterStates[12].dec} />
                  <Counter14 count={counterStates[13].count} onIncrement={counterStates[13].inc} onDecrement={counterStates[13].dec} />
                  <Counter15 count={counterStates[14].count} onIncrement={counterStates[14].inc} onDecrement={counterStates[14].dec} />
                  <Counter16 count={counterStates[15].count} onIncrement={counterStates[15].inc} onDecrement={counterStates[15].dec} />
                  <Counter17 count={counterStates[16].count} onIncrement={counterStates[16].inc} onDecrement={counterStates[16].dec} />
                  <Counter18 count={counterStates[17].count} onIncrement={counterStates[17].inc} onDecrement={counterStates[17].dec} />
                  <Counter19 count={counterStates[18].count} onIncrement={counterStates[18].inc} onDecrement={counterStates[18].dec} />
                  <Counter20 count={counterStates[19].count} onIncrement={counterStates[19].inc} onDecrement={counterStates[19].dec} />
                </div>
                
                {/* Forms Section */}
                <h2 style={{ margin: '20px' }}>📝 Forms (5 with validation)</h2>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))', gap: '20px' }}>
                  <ContactForm />
                  <LoginForm />
                  <PaymentForm />
                  <AddressForm />
                  <ProductForm />
                </div>
                
                {/* Charts Section */}
                <h2 style={{ margin: '20px' }}>📈 Charts (6 types)</h2>
                <ExpandedCharts />
                <DataChart />
                
                {/* User Profile */}
                <UserProfile />
                <TodoList />
              </div>
              <Footer />
            </div>
          </ModalContext.Provider>
        </NotificationContext.Provider>
      </UserContext.Provider>
    </ThemeContext.Provider>
  );
}

// Missing component definitions that were referenced
function ContactForm() {
  const { register, handleSubmit, formState: { errors }, reset } = useForm({ resolver: zodResolver(contactSchema) });
  const onSubmit = (data) => { console.log('Contact:', data); reset(); };
  return ( <FadeIn delay={350}><div style={cardStyle}><h3>📧 Contact Form</h3><form onSubmit={handleSubmit(onSubmit)}><input {...register('name')} placeholder="Name" style={inputStyle} />{errors.name && <span style={{ color: '#dc3545' }}>{errors.name.message}</span>}<input {...register('email')} placeholder="Email" style={inputStyle} />{errors.email && <span style={{ color: '#dc3545' }}>{errors.email.message}</span>}<textarea {...register('message')} placeholder="Message" rows="3" style={inputStyle} />{errors.message && <span style={{ color: '#dc3545' }}>{errors.message.message}</span>}<button type="submit" style={buttonStyle}>Send</button></form></div></FadeIn> );
}

function UserProfile() {
  const { user, loading, error, fetchUser } = useContext(UserContext);
  const [userId, setUserId] = useLocalStorage('userId', 1);
  useEffect(() => { fetchUser(userId); }, [userId, fetchUser]);
  if (loading) return <div style={cardStyle}>⏳ Loading...</div>;
  if (error) return <div style={cardStyle}>❌ Error: {error}</div>;
  if (!user) return <div style={cardStyle}>👤 No user</div>;
  return ( <FadeIn delay={200}><div style={cardStyle}><h3>👤 User Profile</h3><p><strong>Name:</strong> {user.name}</p><p><strong>Email:</strong> {user.email}</p><p><strong>Phone:</strong> {user.phone}</p><div><button onClick={() => setUserId(prev => Math.max(1, prev - 1))} style={buttonStyle}>◀ Prev</button><button onClick={() => setUserId(prev => prev + 1)} style={buttonStyle}>Next ▶</button></div></div></FadeIn> );
}

function TodoList() {
  const [todos, setTodos] = useState([]);
  const [newTodo, setNewTodo] = useState('');
  const addTodo = () => { if (newTodo.trim()) { setTodos([...todos, { id: Date.now(), text: newTodo, completed: false }]); setNewTodo(''); } };
  const toggleTodo = (id) => setTodos(todos.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  const deleteTodo = (id) => setTodos(todos.filter(t => t.id !== id));
  return ( <FadeIn delay={300}><div style={cardStyle}><h3>✅ Todo List</h3><div><input value={newTodo} onChange={(e) => setNewTodo(e.target.value)} onKeyPress={(e) => e.key === 'Enter' && addTodo()} placeholder="Add todo..." /><button onClick={addTodo}>Add</button></div><ul>{todos.map(todo => (<li key={todo.id}><input type="checkbox" checked={todo.completed} onChange={() => toggleTodo(todo.id)} /><span style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>{todo.text}</span><button onClick={() => deleteTodo(todo.id)}>🗑️</button></li>))}</ul></div></FadeIn> );
}

function DataChart() {
  const lineData = { labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'], datasets: [{ label: 'Sales', data: [65, 59, 80, 81, 56, 90], borderColor: '#00aaff', tension: 0.4 }] };
  const barData = { labels: ['A', 'B', 'C', 'D', 'E'], datasets: [{ label: 'Revenue', data: [120, 90, 150, 80, 200], backgroundColor: '#36a2eb' }] };
  const options = { responsive: true, plugins: { legend: { labels: { color: '#fff' } } }, scales: { x: { ticks: { color: '#ccc' } }, y: { ticks: { color: '#ccc' } } } };
  return ( <FadeIn delay={450}><div style={cardStyle}><h3>📈 Sales Charts</h3><div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}><div><Line data={lineData} options={options} /></div><div><Bar data={barData} options={options} /></div></div></div></FadeIn> );
}

const inputStyle = { width: '100%', padding: '10px', margin: '5px 0', borderRadius: 5, border: '1px solid #ccc', background: 'rgba(0,0,0,0.3)', color: '#fff' };

// ==================== MOUNT APP ====================
const root = createRoot(document.getElementById('root'));
root.render(<App />);