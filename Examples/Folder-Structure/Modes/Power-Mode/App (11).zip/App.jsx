// CLJ Power App - No React Required


import { useState, useEffect, useRef, mount } from '../lib/.power.js/runtime';
import { Modal, Slider, Switch, Rating, ProgressBar, Accordion, Carousel, Tooltip, Chart, DatePicker, ColorPicker, CodeEditor, VirtualList, Audio, VideoPlayer, Form, Toast, DragDrop } from '../lib/.power.js/ui';
import { particleNebula, galaxySpiral3D, quantumWave, rotatingCube3D, torusKnot3D, sphereWave3D, particleField3D, spiral3D } from '../lib/.power.js/3d';
import { quantumDimension4D, timeWarp4D, hypercube4D } from '../lib/.power.js/4d';


console.log('🔍 DEBUG: App.jsx loading...');

function App() {
  console.log('🔍 DEBUG: App function called');
  
  const [count, setCount] = __CLJ_useState(0);
  const [theme, setTheme] = __CLJ_useState('dark');
  const [todos, setTodos] = __CLJ_useState([]);
  const [newTodo, setNewTodo] = __CLJ_useState('');
  const [userId, setUserId] = __CLJ_useState(1);
  const [user, setUser] = __CLJ_useState(null);
  const [loading, setLoading] = __CLJ_useState(false);
  const [activeTab, setActiveTab] = __CLJ_useState('counters');
  const [showVideo, setShowVideo] = __CLJ_useState(false);
  const [animIntensity, setAnimIntensity] = __CLJ_useState(1);
  const [rippleColor, setRippleColor] = __CLJ_useState('rgba(0,170,255,.4)');
  const [cardHoverEnabled, setCardHoverEnabled] = __CLJ_useState(true);
  const [sliderValue, setSliderValue] = __CLJ_useState(50);
  const [switchEnabled, setSwitchEnabled] = __CLJ_useState(true);
  const [ratingValue, setRatingValue] = __CLJ_useState(4);
  const [progressValue, setProgressValue] = __CLJ_useState(65);
  const [chartData, setChartData] = __CLJ_useState([30, 50, 80, 45, 70, 25, 90]);
  
  const sliderContainerRef = __CLJ_useRef(null);
  const switchContainerRef = __CLJ_useRef(null);
  const ratingContainerRef = __CLJ_useRef(null);
  const progressContainerRef = __CLJ_useRef(null);
  const accordionContainerRef = __CLJ_useRef(null);
  const carouselContainerRef = __CLJ_useRef(null);
  const tooltipTargetRef = __CLJ_useRef(null);
  const chartContainerRef = __CLJ_useRef(null);
  const datePickerContainerRef = __CLJ_useRef(null);
  const colorPickerContainerRef = __CLJ_useRef(null);
  const codeEditorContainerRef = __CLJ_useRef(null);
  const virtualListContainerRef = __CLJ_useRef(null);
  const audioContainerRef = __CLJ_useRef(null);
  const videoContainerRef = __CLJ_useRef(null);
  const formContainerRef = __CLJ_useRef(null);

  const counterStates = Array(20).fill().map(() => {
    const [c, setC] = __CLJ_useState(0);
    return { count: c, inc: () => { console.log('🔍 DEBUG: Counter inc called'); setC(c => c + 1); }, dec: () => { console.log('🔍 DEBUG: Counter dec called'); setC(c => Math.max(0, c - 1)); } };
  });

  __CLJ_useEffect(() => {
    console.log('🔍 DEBUG: useEffect mounted - initializing components');
    setTimeout(() => setShowVideo(true), 1000);
    
    if (typeof CLJ !== 'undefined') {
      console.log('🔍 DEBUG: CLJ object found, initializing UI components');
      if (sliderContainerRef.current) new CLJ.Slider(sliderContainerRef.current, { min: 0, max: 100, value: sliderValue, step: 1, onChange: (val) => { console.log('🔍 DEBUG: Slider changed:', val); setSliderValue(val); } });
      if (switchContainerRef.current) new CLJ.Switch(switchContainerRef.current, { checked: switchEnabled, onChange: (val) => { console.log('🔍 DEBUG: Switch changed:', val); setSwitchEnabled(val); } });
      if (ratingContainerRef.current) new CLJ.Rating(ratingContainerRef.current, { max: 5, value: ratingValue, onChange: (val) => { console.log('🔍 DEBUG: Rating changed:', val); setRatingValue(val); } });
      if (progressContainerRef.current) { const pb = new CLJ.ProgressBar(progressContainerRef.current, { value: progressValue, max: 100, color: '#00aaff' }); setTimeout(() => pb.setValue(progressValue), 500); }
      if (accordionContainerRef.current) new CLJ.Accordion(accordionContainerRef.current, [
        { title: '🚀 Getting Started', content: '<p style="color:#ddd;">CLJ POWER v4.0 • 90 Animations • 3D/4D WebGL • 22 UI Components</p>', open: true },
        { title: '🎮 Counters', content: '<p style="color:#ddd;">20 interactive counters with ripple effects.</p>', open: false },
        { title: '📝 Todos', content: '<p style="color:#ddd;">Full CRUD with CLJ.Toast notifications.</p>', open: false },
        { title: '👤 User Explorer', content: '<p style="color:#ddd;">Fetch and display user data with CLJ.fetch.</p>', open: false }
      ]);
      if (carouselContainerRef.current) new CLJ.Carousel(carouselContainerRef.current, ['https://picsum.photos/800/400?random=1','https://picsum.photos/800/400?random=2','https://picsum.photos/800/400?random=3','https://picsum.photos/800/400?random=4','https://picsum.photos/800/400?random=5'], { interval: 4000, auto: true });
      if (tooltipTargetRef.current) new CLJ.Tooltip(tooltipTargetRef.current, 'CLJ POWER v4.0! 🚀', { position: 'top' });
      if (chartContainerRef.current) new CLJ.Chart(chartContainerRef.current, { type: 'line', data: chartData, labels: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], colors: ['#00aaff'] });
      if (datePickerContainerRef.current) new CLJ.DatePicker(datePickerContainerRef.current, { value: new Date() });
      if (colorPickerContainerRef.current) new CLJ.ColorPicker(colorPickerContainerRef.current, { value: rippleColor, onChange: (color) => setRippleColor(color) });
      if (codeEditorContainerRef.current) new CLJ.CodeEditor(codeEditorContainerRef.current, { value: '// CLJ v4.0\nconsole.log("Hello CLJ!");', height: '150px' });
      if (virtualListContainerRef.current) new CLJ.VirtualList(virtualListContainerRef.current, { items: Array(1000).fill().map((_, i) => `Item #${i+1}`), itemHeight: 40, renderItem: (item) => `<div style="padding:10px;border-bottom:1px solid #333;">📋 ${item}</div>` });
      if (audioContainerRef.current) { const audio = new CLJ.Audio({ visualization: true }); if (audio.getCanvas()) audioContainerRef.current.appendChild(audio.getCanvas()); }
      if (videoContainerRef.current) new CLJ.VideoPlayer(videoContainerRef.current, { src: 'https://www.w3schools.com/html/mov_bbb.mp4', controls: true });
      if (formContainerRef.current) new CLJ.Form(formContainerRef.current, { fields: { name: { required: true, minLength: 2 }, email: { required: true, pattern: '^[\\w.-]+@[\\w.-]+\\.\\w+$' }, message: { required: true, minLength: 10 } }, onSubmit: (data) => { CLJ.Toast.show('✅ Form submitted!', 3000); console.log('🔍 DEBUG: Form submitted:', data); } });
    } else {
      console.log('🔍 DEBUG: CLJ object NOT found - components not initialized');
    }
  }, []);

  const addTodo = () => {
    console.log('🔍 DEBUG: addTodo called, newTodo:', newTodo);
    if (newTodo.trim()) {
      setTodos([...todos, { id: Date.now(), text: newTodo, done: false }]);
      setNewTodo('');
      if (typeof CLJ !== 'undefined') CLJ.Toast.show('✅ Task added!', 2500);
    }
  };

  const toggleTodo = (id) => { console.log('🔍 DEBUG: toggleTodo called, id:', id); setTodos(todos.map(t => t.id === id ? { ...t, done: !t.done } : t)); };
  
  const deleteTodo = (id) => {
    console.log('🔍 DEBUG: deleteTodo called, id:', id);
    setTodos(todos.filter(t => t.id !== id));
    if (typeof CLJ !== 'undefined') CLJ.Toast.show('🗑️ Task deleted', 2000);
  };

  const fetchUser = async (id) => {
    console.log('🔍 DEBUG: fetchUser called, id:', id);
    setLoading(true);
    try {
      const u = await (typeof CLJ !== 'undefined' && CLJ.fetch ? CLJ.fetch.get(`https://jsonplaceholder.typicode.com/users/${id}`, { cache: true, cacheTTL: 30000, responseType: 'json' }) : fetch(`https://jsonplaceholder.typicode.com/users/${id}`).then(r => r.json()));
      setUser(u);
      if (typeof CLJ !== 'undefined') CLJ.Toast.show('👤 ' + u.name, 2500);
    } catch(e) {
      console.log('🔍 DEBUG: fetchUser error:', e.message);
      if (typeof CLJ !== 'undefined') CLJ.Toast.show('❌ Failed to load', 3000);
    }
    setLoading(false);
  };

  __CLJ_useEffect(() => { fetchUser(userId); }, [userId]);

  const handleRipple = (e, color) => {
    console.log('🔍 DEBUG: handleRipple called');
    if (typeof __CLJ_interact !== 'undefined') __CLJ_interact.rippleEffect(e, color || rippleColor);
  };

  // FIXED: createButton with debug logging
  const createButton = (text, className, onClick, styleOverrides = {}) => {
    console.log('🔍 DEBUG: createButton called for:', text);
    const btn = document.createElement('button');
    btn.textContent = text;
    btn.className = className || 'clj-btn';
    Object.assign(btn.style, {
      padding: '10px 20px', borderRadius: '8px', border: 'none',
      color: 'white', cursor: 'pointer', fontWeight: 'bold',
      ...styleOverrides
    });
    // FIXED: Use onclick property directly like the Settings button
    btn.onclick = function(e) {
      console.log('🔍 DEBUG: Button clicked:', text);
      onClick(e);
    };
    return btn;
  };

  const openSettingsModal = () => {
    console.log('🔍 DEBUG: openSettingsModal called');
    if (typeof CLJ !== 'undefined') {
      new CLJ.Modal({
        title: '⚙️ POWER Mode v4.0 Settings',
        content: `<div style="color:#ddd;"><p><strong>Animation Intensity:</strong> ${animIntensity}x</p><p><strong>Ripple Color:</strong> ${rippleColor}</p><p><strong>Switch:</strong> ${switchEnabled ? 'ON' : 'OFF'}</p><p><strong>Rating:</strong> ${'★'.repeat(ratingValue)}${'☆'.repeat(5-ratingValue)}</p><p><strong>Progress:</strong> ${progressValue}%</p><hr style="border-color:#333;margin:15px 0;"><p style="font-size:12px;opacity:0.6;">CLJ POWER v4.0 • 90 Animations • 3D/4D WebGL • 22 Components</p></div>`
      }).open();
    }
  };

  const Counter = ({ count, inc, dec, label, color }) => {
    const card = document.createElement('div');
    card.className = 'clj-card';
    card.style.cssText = `background:linear-gradient(135deg,${color||'rgba(255,255,255,0.1)'},rgba(255,255,255,0.05));backdrop-filter:blur(10px);border-radius:15px;padding:20px;margin:10px;border:1px solid rgba(255,255,255,0.2);text-align:center;`;
    
    const title = document.createElement('h2');
    title.style.cssText = 'font-size:24px;margin:0 0 10px;';
    title.textContent = `${label}: ${count}`;
    
    const btnContainer = document.createElement('div');
    btnContainer.style.cssText = 'display:flex;gap:10px;justify-content:center;';
    
    // FIXED: Buttons use onclick property directly
    const decBtn = document.createElement('button');
    decBtn.textContent = '-';
    decBtn.className = 'clj-btn danger-btn';
    decBtn.style.cssText = 'padding:12px 24px;border-radius:8px;border:none;background:linear-gradient(135deg,#dc3545,#a71d2a);color:white;cursor:pointer;font-weight:bold;font-size:18px;';
    decBtn.onclick = function(e) { console.log('🔍 DEBUG: Counter dec clicked:', label); handleRipple(e, 'rgba(220,53,69,.3)'); dec(); };
    
    const incBtn = document.createElement('button');
    incBtn.textContent = '+';
    incBtn.className = 'clj-btn action-btn';
    incBtn.style.cssText = 'padding:12px 24px;border-radius:8px;border:none;background:linear-gradient(135deg,#28a745,#1e7e34);color:white;cursor:pointer;font-weight:bold;font-size:18px;';
    incBtn.onclick = function(e) { console.log('🔍 DEBUG: Counter inc clicked:', label); handleRipple(e, 'rgba(40,167,69,.3)'); inc(); };
    
    btnContainer.appendChild(decBtn);
    btnContainer.appendChild(incBtn);
    card.appendChild(title);
    card.appendChild(btnContainer);
    return card;
  };

  const colors = ['#ff6384','#36a2eb','#ffce56','#4bc0c0','#9966ff','#ff9f40','#c9cbcf','#7bc8a4','#e8c3b9','#71b7e6','#ff6b6b','#48dbfb','#ff9ff3','#54a0ff','#5f27cd','#01a3a4','#f368e0','#ff6348','#0abde3','#10ac84'];

  // FIXED: Tab buttons built inside a container div instead of returned as array
  const buildTabButtons = () => {
    console.log('🔍 DEBUG: buildTabButtons called, activeTab:', activeTab);
    const container = document.createElement('div');
    container.style.cssText = 'display:flex;gap:10px;flex-wrap:wrap;align-items:center;';
    
    const tabs = [
      { text: '🎮 Counters', tab: 'counters' },
      { text: '📝 Todos', tab: 'todos' },
      { text: '👤 Users', tab: 'users' },
      { text: '🧩 Components', tab: 'components' },
      { text: '📊 Charts+', tab: 'charts' }
    ];
    
    tabs.forEach(t => {
      const btn = document.createElement('button');
      btn.textContent = t.text;
      btn.className = 'clj-btn tab-btn';
      const isActive = activeTab === t.tab;
      btn.style.cssText = `padding:10px 20px;border-radius:8px;border:none;background:${isActive ? 'linear-gradient(135deg,#007bff,#0056b3)' : 'rgba(255,255,255,0.1)'};color:white;cursor:pointer;`;
      btn.onclick = function(e) {
        console.log('🔍 DEBUG: Tab clicked:', t.tab);
        handleRipple(e);
        setActiveTab(t.tab);
      };
      container.appendChild(btn);
    });
    
    // Tooltip
    const tooltipSpan = document.createElement('span');
    tooltipSpan.textContent = '💡';
    tooltipSpan.style.cssText = 'cursor:help;font-size:20px;';
    tooltipSpan.setAttribute('data-ref', 'tooltip');
    container.appendChild(tooltipSpan);
    
    // Settings button
    const settingsBtn = document.createElement('button');
    settingsBtn.textContent = '⚙️ Settings';
    settingsBtn.className = 'clj-btn clj-pulseGlow';
    settingsBtn.style.cssText = 'padding:10px 20px;border-radius:8px;border:none;background:linear-gradient(135deg,#aa44ff,#ff44aa);color:white;cursor:pointer;font-weight:bold;';
    settingsBtn.onclick = function(e) {
      console.log('🔍 DEBUG: Settings button clicked');
      handleRipple(e, 'rgba(255,255,255,.5)');
      openSettingsModal();
    };
    container.appendChild(settingsBtn);
    
    return container;
  };

  console.log('🔍 DEBUG: App rendering...');

  // Build main container
  const mainDiv = document.createElement('div');
  mainDiv.style.cssText = 'min-height:100vh;background:linear-gradient(180deg,#020210 0%,#0a0a2a 50%,#020210 100%);color:#fff;font-family:-apple-system,BlinkMacSystemFont,sans-serif;overflow:hidden;';

  // Header
  const header = document.createElement('header');
  header.className = 'clj-gradientShift';
  header.style.cssText = 'padding:20px 40px;background:linear-gradient(270deg,rgba(10,10,30,0.95),rgba(20,10,40,0.95),rgba(10,10,30,0.95));background-size:300% 300%;backdrop-filter:blur(20px);display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,0.1);position:sticky;top:0;z-index:100;';
  
  const headerLeft = document.createElement('div');
  const h1 = document.createElement('h1');
  h1.className = 'clj-textGlow';
  h1.style.cssText = 'font-size:32px;background:linear-gradient(135deg,#00aaff,#aa44ff,#ff44aa);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin:0;';
  h1.textContent = '⚡ CLJ Power Engine v4.0';
  const subtitle = document.createElement('p');
  subtitle.style.cssText = 'margin:5px 0 0;opacity:0.7;font-size:14px;';
  subtitle.textContent = 'No React • 90 Animations • 3D/4D WebGL • 22 Components • Pure CLJ Runtime';
  headerLeft.appendChild(h1);
  headerLeft.appendChild(subtitle);
  
  const headerRight = buildTabButtons();
  
  header.appendChild(headerLeft);
  header.appendChild(headerRight);
  mainDiv.appendChild(header);

  // Content area
  const content = document.createElement('div');
  content.style.cssText = 'max-width:1400px;margin:0 auto;padding:40px 20px;position:relative;z-index:1;';
  
  // Counters section
  const countersSection = document.createElement('div');
  countersSection.style.display = activeTab === 'counters' ? 'block' : 'none';
  
  const countersTitle = document.createElement('h2');
  countersTitle.className = 'clj-rainbowText';
  countersTitle.style.cssText = 'text-align:center;font-size:28px;margin-bottom:10px;';
  countersTitle.textContent = '🎮 20 Interactive Counters';
  
  const countersSubtitle = document.createElement('p');
  countersSubtitle.style.cssText = 'text-align:center;opacity:0.6;margin-bottom:30px;';
  countersSubtitle.textContent = `Total: ${counterStates.reduce((s,c) => s + c.count, 0)}`;
  
  const countersGrid = document.createElement('div');
  countersGrid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:15px;';
  
  counterStates.forEach((cs, i) => {
    countersGrid.appendChild(Counter({ count: cs.count, inc: cs.inc, dec: cs.dec, label: `Counter ${i+1}`, color: colors[i] }));
  });
  
  countersSection.appendChild(countersTitle);
  countersSection.appendChild(countersSubtitle);
  countersSection.appendChild(countersGrid);
  content.appendChild(countersSection);

  // Todos section
  const todosSection = document.createElement('div');
  todosSection.style.display = activeTab === 'todos' ? 'block' : 'none';
  
  const todosTitle = document.createElement('h2');
  todosTitle.className = 'clj-rainbowText';
  todosTitle.style.cssText = 'text-align:center;font-size:28px;margin-bottom:30px;';
  todosTitle.textContent = `📝 Todo List (${todos.length})`;
  todosSection.appendChild(todosTitle);
  
  const todosCard = document.createElement('div');
  todosCard.className = 'clj-card clj-glass';
  todosCard.style.cssText = 'max-width:600px;margin:0 auto;padding:30px;';
  
  const todosInputRow = document.createElement('div');
  todosInputRow.style.cssText = 'display:flex;gap:10px;margin-bottom:20px;';
  
  const todoInput = document.createElement('input');
  todoInput.value = newTodo;
  todoInput.placeholder = '✨ Add a task...';
  todoInput.style.cssText = 'flex:1;padding:15px 20px;border-radius:10px;border:1px solid rgba(255,255,255,0.2);background:rgba(0,0,0,0.3);color:#fff;font-size:16px;';
  todoInput.oninput = (e) => setNewTodo(e.target.value);
  todoInput.onkeydown = (e) => { if (e.key === 'Enter') addTodo(); };
  
  const addBtn = document.createElement('button');
  addBtn.textContent = '➕ Add';
  addBtn.className = 'clj-btn action-btn';
  addBtn.style.cssText = 'padding:15px 30px;border-radius:10px;border:none;background:linear-gradient(135deg,#28a745,#1e7e34);color:white;cursor:pointer;font-weight:bold;font-size:16px;';
  addBtn.onclick = function(e) { console.log('🔍 DEBUG: Add todo clicked'); handleRipple(e, 'rgba(40,167,69,.4)'); addTodo(); };
  
  todosInputRow.appendChild(todoInput);
  todosInputRow.appendChild(addBtn);
  todosCard.appendChild(todosInputRow);
  
  if (todos.length === 0) {
    const emptyMsg = document.createElement('p');
    emptyMsg.style.cssText = 'text-align:center;opacity:0.5;';
    emptyMsg.textContent = 'No tasks yet. 🎉';
    todosCard.appendChild(emptyMsg);
  }
  
  todos.forEach(t => {
    const row = document.createElement('div');
    row.style.cssText = 'display:flex;align-items:center;gap:10px;padding:12px 15px;background:rgba(255,255,255,0.05);border-radius:8px;margin-bottom:8px;';
    
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = t.done;
    checkbox.style.cssText = 'width:20px;height:20px;cursor:pointer;';
    checkbox.onchange = () => toggleTodo(t.id);
    
    const span = document.createElement('span');
    span.style.cssText = `flex:1;font-size:16px;text-decoration:${t.done?'line-through':'none'};opacity:${t.done?0.5:1};`;
    span.textContent = t.text;
    
    const delBtn = document.createElement('button');
    delBtn.textContent = '🗑️';
    delBtn.className = 'clj-btn danger-btn';
    delBtn.style.cssText = 'padding:8px 12px;border-radius:6px;border:none;background:rgba(220,53,69,0.3);color:#dc3545;cursor:pointer;font-size:16px;';
    delBtn.onclick = function(e) { console.log('🔍 DEBUG: Delete todo clicked:', t.id); handleRipple(e, 'rgba(220,53,69,.4)'); deleteTodo(t.id); };
    
    row.appendChild(checkbox);
    row.appendChild(span);
    row.appendChild(delBtn);
    todosCard.appendChild(row);
  });
  
  todosSection.appendChild(todosCard);
  content.appendChild(todosSection);

  // Users section
  const usersSection = document.createElement('div');
  usersSection.style.display = activeTab === 'users' ? 'block' : 'none';
  
  const usersTitle = document.createElement('h2');
  usersTitle.className = 'clj-rainbowText';
  usersTitle.style.cssText = 'text-align:center;font-size:28px;margin-bottom:30px;';
  usersTitle.textContent = '👤 User Explorer';
  usersSection.appendChild(usersTitle);
  
  const usersCard = document.createElement('div');
  usersCard.className = 'clj-card clj-glass';
  usersCard.style.cssText = 'max-width:500px;margin:0 auto;padding:30px;text-align:center;';
  
  if (loading) {
    usersCard.innerHTML = '<div style="width:50px;height:50px;border-radius:50%;border:4px solid rgba(255,255,255,0.1);border-top:4px solid #00aaff;animation:spin 1s linear infinite;margin:0 auto 20px;"></div><p style="opacity:0.7;">Loading...</p>';
  } else if (user) {
    usersCard.innerHTML = `<div style="width:100px;height:100px;border-radius:50%;background:linear-gradient(135deg,#00aaff,#aa44ff);display:flex;align-items:center;justify-content:center;margin:0 auto 20px;font-size:40px;">${user.name.charAt(0)}</div><h2>${user.name}</h2><p style="opacity:0.7;">📧 ${user.email}</p><p style="opacity:0.7;">📞 ${user.phone}</p><p style="opacity:0.7;">🌐 ${user.website}</p>`;
  } else {
    usersCard.innerHTML = '<p style="opacity:0.5;">No user data</p>';
  }
  
  const navRow = document.createElement('div');
  navRow.style.cssText = 'display:flex;gap:10px;justify-content:center;margin-top:20px;';
  
  const prevBtn = document.createElement('button');
  prevBtn.textContent = '◀ Prev';
  prevBtn.className = 'clj-btn';
  prevBtn.style.cssText = 'padding:12px 30px;border-radius:10px;border:none;background:linear-gradient(135deg,#6c757d,#495057);color:white;cursor:pointer;font-weight:bold;font-size:16px;';
  prevBtn.onclick = function(e) { console.log('🔍 DEBUG: Prev user clicked'); handleRipple(e); setUserId(Math.max(1, userId - 1)); };
  
  const userIdSpan = document.createElement('span');
  userIdSpan.style.cssText = 'padding:12px 20px;border-radius:10px;background:rgba(255,255,255,0.1);font-weight:bold;';
  userIdSpan.textContent = `#${userId}`;
  
  const nextBtn = document.createElement('button');
  nextBtn.textContent = 'Next ▶';
  nextBtn.className = 'clj-btn';
  nextBtn.style.cssText = 'padding:12px 30px;border-radius:10px;border:none;background:linear-gradient(135deg,#007bff,#0056b3);color:white;cursor:pointer;font-weight:bold;font-size:16px;';
  nextBtn.onclick = function(e) { console.log('🔍 DEBUG: Next user clicked'); handleRipple(e, 'rgba(0,123,255,.4)'); setUserId(userId + 1); };
  
  navRow.appendChild(prevBtn);
  navRow.appendChild(userIdSpan);
  navRow.appendChild(nextBtn);
  
  usersSection.appendChild(usersCard);
  usersSection.appendChild(navRow);
  content.appendChild(usersSection);

  // Components section (simplified for fix)
  const compSection = document.createElement('div');
  compSection.style.display = activeTab === 'components' ? 'block' : 'none';
  compSection.innerHTML = `<h2 class="clj-rainbowText" style="text-align:center;font-size:28px;margin-bottom:10px;">🧩 22 UI Components</h2><p style="text-align:center;opacity:0.6;margin-bottom:30px;">3D/4D WebGL + Full Component Library</p>`;
  
  const compGrid = document.createElement('div');
  compGrid.style.cssText = 'display:grid;grid-template-columns:repeat(auto-fit,minmax(400px,1fr));gap:25px;';
  compGrid.innerHTML = `
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>🎚️ Slider (${sliderValue})</h3><div id="slider-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>🔘 Switch (${switchEnabled?'ON':'OFF'})</h3><div id="switch-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>⭐ Rating (${ratingValue}/5)</h3><div id="rating-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>📊 Progress (${progressValue}%)</h3><div id="progress-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>📅 Date Picker</h3><div id="date-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>🎨 Color Picker</h3><div id="color-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>📋 Accordion</h3><div id="accordion-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>🎠 Carousel</h3><div id="carousel-ref" style="height:220px;border-radius:12px;overflow:hidden;"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>💻 Code Editor</h3><div id="code-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>📜 Virtual List (1000 items)</h3><div id="vlist-ref" style="height:200px;overflow:auto;"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>🎵 Audio Visualizer</h3><div id="audio-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>🎬 Video Player</h3><div id="video-ref"></div></div>
    <div class="clj-card clj-frosted" style="padding:25px;"><h3>📝 Form Validation</h3><form id="form-ref"><input name="name" placeholder="Name" style="display:block;width:100%;margin:8px 0;padding:10px;border-radius:6px;border:1px solid #333;background:#1a1a2e;color:#fff;"><input name="email" placeholder="Email" style="display:block;width:100%;margin:8px 0;padding:10px;border-radius:6px;border:1px solid #333;background:#1a1a2e;color:#fff;"><textarea name="message" placeholder="Message" style="display:block;width:100%;margin:8px 0;padding:10px;border-radius:6px;border:1px solid #333;background:#1a1a2e;color:#fff;min-height:60px;"></textarea><button type="submit" style="padding:12px 30px;border-radius:8px;border:none;background:linear-gradient(135deg,#28a745,#1e7e34);color:white;cursor:pointer;font-weight:bold;">Submit</button></form></div>
  `;
  compSection.appendChild(compGrid);
  content.appendChild(compSection);

  // Charts section
  const chartsSection = document.createElement('div');
  chartsSection.style.display = activeTab === 'charts' ? 'block' : 'none';
  chartsSection.innerHTML = `<h2 class="clj-rainbowText" style="text-align:center;font-size:28px;margin-bottom:30px;">📊 Charts & Data</h2><div class="clj-card clj-frosted" style="padding:25px;"><h3>📈 Line Chart</h3><div id="chart-ref"></div></div>`;
  content.appendChild(chartsSection);

  mainDiv.appendChild(content);

  // Footer
  const footer = document.createElement('footer');
  footer.className = 'clj-glass';
  footer.style.cssText = 'text-align:center;padding:30px;border-top:1px solid rgba(255,255,255,0.1);margin-top:40px;position:relative;z-index:1;';
  footer.innerHTML = `<p style="opacity:0.7;">⚡ CLJ Power Engine v4.0 • 90 Animations • 3D/4D WebGL • 22 Components • No React • No Dependencies</p><p style="opacity:0.5;font-size:14px;">Device: ${window.__CLJ_device?.isMobile ? '📱 Mobile' : window.__CLJ_device?.isTablet ? '📋 Tablet' : '🖥️ Desktop'} • ${window.__CLJ_device?.width}x${window.__CLJ_device?.height}</p>`;
  mainDiv.appendChild(footer);

  console.log('🔍 DEBUG: App render complete, returning mainDiv');
  return mainDiv;
}

console.log('🔍 DEBUG: Mounting app...');
__CLJ_mount(App, 'root');